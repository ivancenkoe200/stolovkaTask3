﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class OrderDetail
{
    public int OrderId { get; set; }

    public int DishId { get; set; }

    public int Quantity { get; set; }

    public decimal PriceAtOrder { get; set; }

    public virtual Menu Dish { get; set; } = null!;

    public virtual Order Order { get; set; } = null!;
}
